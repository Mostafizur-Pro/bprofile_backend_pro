const mysql = require("mysql2");

export const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "bprofile",
  // waitForConnections: true,
  // connectionLimit: 10,
  // queueLimit: 0,
});
